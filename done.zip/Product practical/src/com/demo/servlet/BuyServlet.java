package com.demo.servlet;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class BuyServlet extends HttpServlet {
	public void doGet(HttpServletRequest request,HttpServletResponse response)
	{

	}

}
