package com.demo.service;

import java.util.List;

import com.demo.beans.ProductPOJO;
import com.demo.dao.ProductDao;
import com.demo.dao.ProductDaoImpl;

public class ProductServiceImpl implements ProductService {

	ProductDao pdao=new ProductDaoImpl();
	public List<ProductPOJO> getProducts(int cid) {
		         
		return pdao.getProduct(cid);
	}
	@Override
	public ProductPOJO getProductById(int pid) {
		
		return pdao.getProductById(pid);
	}
	@Override
	public boolean updateProduct(int pid,int qty, int prc) {
		
		return pdao.update(pid,qty,prc);
	}

}
