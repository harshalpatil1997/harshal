package com.demo.dao;

import com.demo.beans.MyEmployee;

public interface LoginDao {
		public MyEmployee Validate(String nm,String pass);

	
}
