package com.demo.beans;

public class MyEmployee {

	private String name;
	private String pass;
	private String city;

	public MyEmployee(String name, String pass, String city) {
		super();
		this.name = name;
		this.pass = pass;
		this.city = city;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@Override
	public String toString() {
		return "MyEmployee [name=" + name + ", pass=" + pass + ", city=" + city + "]";
	}

}
