package com.demo.dao;

import java.util.List;

import com.demo.beans.ProductPOJO;

public interface ProductDao {

	public List<ProductPOJO> getProduct(int cid);

}
