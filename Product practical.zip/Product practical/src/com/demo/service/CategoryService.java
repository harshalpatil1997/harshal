package com.demo.service;

import java.util.List;

import com.demo.beans.CategoryPOJO;

public interface CategoryService {
	public List<CategoryPOJO> getAllCategory();

}
