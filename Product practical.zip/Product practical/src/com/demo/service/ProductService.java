package com.demo.service;

import java.util.List;

import com.demo.beans.ProductPOJO;

public interface ProductService {

	List<ProductPOJO> getProducts(int cid);

		
}
