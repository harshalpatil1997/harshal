package com.demo.service;

public interface LoginService {

	public boolean loginValidation(String nm, String pass);

}
