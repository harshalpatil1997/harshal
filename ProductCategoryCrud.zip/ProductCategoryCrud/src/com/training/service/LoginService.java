package com.training.service;

public interface LoginService {

		public boolean validate(String u, String p);
}
